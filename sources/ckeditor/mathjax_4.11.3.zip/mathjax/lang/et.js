/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'et', {
	title: 'Mathematics in TeX', // MISSING
	button: 'Matemaatika',
	dialogInput: 'Write your TeX here', // MISSING
	docUrl: 'http:// MISSING //en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'TeX dokumentatsioon',
	loading: 'laadimine...',
	pathName: 'matemaatika'
} );
